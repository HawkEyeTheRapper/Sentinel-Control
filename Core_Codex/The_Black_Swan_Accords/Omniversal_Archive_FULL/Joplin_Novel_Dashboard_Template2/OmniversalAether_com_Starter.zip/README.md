# OmniversalAether_com Project Structure

This is the scaffolded starter for the Omniversal Aether system.