<?php
/**
 * Title: header
 * Slug: archivist/header
 * Inserter: no
 */
?>
<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"66.66%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:66.66%"><!-- wp:group {"metadata":{"name":"Site logo and title"},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:site-logo {"width":80,"style":{"color":[]}} /-->

<!-- wp:group {"metadata":{"name":"Title and tagline"},"style":{"layout":{"selfStretch":"fill","flexSize":null},"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-group"><!-- wp:group {"metadata":{"name":"Site title wrapper"},"style":{"border":{"bottom":{"width":"1px","style":"dotted"},"top":[],"right":[],"left":[]},"spacing":{"padding":{"top":"0","bottom":"0.25rem"}}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch","verticalAlignment":"center"}} -->
<div class="wp-block-group" style="border-bottom-style:dotted;border-bottom-width:1px;padding-top:0;padding-bottom:0.25rem"><!-- wp:site-title {"level":0,"textAlign":"center"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"metadata":{"name":"Site tagline wrapper"},"style":{"spacing":{"padding":{"bottom":"0.65rem"}}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch","verticalAlignment":"center"}} -->
<div class="wp-block-group" style="padding-bottom:0.65rem"><!-- wp:site-tagline {"textAlign":"center"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:group {"metadata":{"name":"Menu wrapper"},"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"align":"right","metadata":{"name":"["},"style":{"layout":{"selfStretch":"fit","flexSize":null},"typography":{"lineHeight":"1.25"}},"fontSize":"small"} -->
<p class="has-text-align-right has-small-font-size" style="line-height:1.25"><?php /* Translators: 1. is a 'br' HTML element, 2. is a 'br' HTML element */ 
echo sprintf( esc_html__( '[%1$s[%2$s[', 'archivist' ), '<br>', '<br>' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:navigation {"overlayMenu":"never","icon":"menu","layout":{"type":"flex","justifyContent":"center","orientation":"vertical"}} /-->

<!-- wp:paragraph {"metadata":{"name":"]"},"style":{"layout":{"selfStretch":"fit","flexSize":null},"typography":{"lineHeight":"1.25"}},"fontSize":"small"} -->
<p class="has-small-font-size" style="line-height:1.25"><?php /* Translators: 1. is a 'br' HTML element, 2. is a 'br' HTML element */ 
echo sprintf( esc_html__( ']%1$s]%2$s]', 'archivist' ), '<br>', '<br>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"var:preset|spacing|80","metadata":{"name":"XXL"}} -->
<div style="height:var(--wp--preset--spacing--80)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->