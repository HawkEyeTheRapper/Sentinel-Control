<?php declare( strict_types = 1 ); ?>
<?php
/**
 * Archivist functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Archivist
 * @since Archivist 1.0
 */


if ( ! function_exists( 'archivist_support' ) ) :

	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * @since Archivist 1.0
	 *
	 * @return void
	 */
	function archivist_support() {

		// Enqueue editor styles.
		add_editor_style( 'style.css' );

		// Make theme available for translation.
		load_theme_textdomain( 'archivist' );
	}

endif;

add_action( 'after_setup_theme', 'archivist_support' );

if ( ! function_exists( 'archivist_styles' ) ) :

	/**
	 * Enqueue styles.
	 *
	 * @since Archivist 1.0
	 *
	 * @return void
	 */
	function archivist_styles() {

		// Register theme stylesheet.
		wp_register_style(
			'block_canvas-style',
			get_stylesheet_directory_uri() . '/style.css',
			array(),
			wp_get_theme()->get( 'Version' )
		);

		// Enqueue theme stylesheet.
		wp_enqueue_style( 'block_canvas-style' );

	}

endif;

add_action( 'wp_enqueue_scripts', 'archivist_styles' );


// updater for WordPress.com themes
if ( is_admin() )
	include dirname( __FILE__ ) . '/inc/updater.php';
